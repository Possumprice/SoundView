//
//  RunwayAPI.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/26/25.
//

import Foundation
import ShipinKit

final class VideoGenerator: ObservableObject {
    private var runway: RunwayML?
    private var imageUrl: URL?
    private var prompt: String?
    
    func setup(url: URL, promptText: String) {
        runway = RunwayML(apiKey: "{YOUR_API_KEY}")
        imageUrl = url
        prompt = promptText
    }
    
    func generateVideo() async -> URL? {
        guard let runway = runway else {
            return nil
        }
        
        do {
            print("Generating video segment")
            let videoUrl = try await runway.generateVideo(prompt: prompt!, imageURL: imageUrl!, duration: .long)
            return videoUrl
        } catch {
            print("Failed to return video segment: \(error)")
            return nil
        }
    }
    
}
 

/*
struct RunwayAPI {
    
    static let key = "key_14bcc27e60308a18c873af367d360ab09fe83077e88060b5d09412bbee0208d6dde394ee64e6da6bd3f75006aa37db4d0507c41cc77b5e14274f2717320cd812"
    
    public enum TaskStatus: String, Codable, Sendable {
        case pending = "PENDING"
        case throttled = "THROTTLED"
        case running = "RUNNING"
        case succeeded = "SUCCEEDED"
        case failed = "FAILED"
    }
    
    static let endpoint: URL = URL(string: "https://api.dev.runwayml.com/v1/image_to_video")!
    
    static func getVideoTask(fromImageURL image: URL, prompt: String, frames: Int = 375, seed: Int? = nil, completion: @escaping (String?) -> Void) {
        print("Getting task")
        //build api request
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("2024-11-06", forHTTPHeaderField: "X-Runway-Version")
        
        //parameters, user will be able to change
        let body : [String : Any] = [
            "promptImage" : image,
            "model" : "gen4_turbo",
            "promptText" : prompt,
            "duration" : 10,
            //"num_frames" : frames,
            //"fps" : 25, //for now, can up depending on time to generate
            "ratio": "1280:720"
        ]
        
        
        //Add error protection below
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        } catch {
            print ("Error encoding Runway request: \(error)")
            completion(nil)
            return
        }
        
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error while generating video \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("No Runway data returned")
                completion(nil)
                return
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String : Any],
                   let taskID = json["id"] as? String {
                    print("Runway task started")
                    completion(taskID)
                } else {
                    print("No Runway url produced")
                    completion(nil)
                }
            } catch {
                print("Error decoding json object returned by Runway")
                completion(nil)
            }
        }.resume()
    }
}
*/
