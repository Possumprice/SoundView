//
//  ContentView.swift
//  Soundview
//
//  Created by Lincoln Price on 12/21/24.
//
//

import SwiftUI
import AVFoundation
import Photos

struct ContentView: View {
    
    // MARK: - Properties
    @ObservedObject var promptGenerator = PromptGenerator()
    @ObservedObject var imageGenerator = ImageGenerator()
    @ObservedObject var videoGenerator = VideoGenerator()
    
    @State private var generatedPrompts: [String] = []
    @State private var generatedImages: [URL] = []
    
    @State private var showingPromptPrev = false
    @State private var showingImagePrev = false
    @State private var showingDeleteConfirm = false
    @State private var showingGenerationOptions = false
    @State private var showingAppInfo = false
    @State private var showingAppSettings = false
    
    @State private var promptText = ""
    @State private var videoURL: URL? = nil
    @State private var isGenerating = false
    @State private var progressMessage = ""
    
    @State private var durationLimit: Double = 10.0
    @State private var songDuration: Double = 180.0
    @State private var songStartTime: Double = 0.0
    
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isAudioing = false
    @State private var songNotChosen = true
    
    @State private var selectedUrl: URL? = nil
    @State private var showingFileImporter = false
    
    private var gradient: some View {
        LinearGradient(gradient: Gradient(colors: [.gray, .black]), startPoint: .leading, endPoint: .trailing)
            .flipsForRightToLeftLayoutDirection(false).ignoresSafeArea()
    }
    
    // MARK: - Layout
    var body: some View {
        
        //will only be shown when images and prompts are generated to confirm with user
        if showingImagePrev {
            ImagesView(imageUrls: generatedImages, prompts: generatedPrompts) {
                generateVideo()
                showingImagePrev = false
            }
        } else {
            NavigationView {
                HStack {
                    VStack {
                        //App Title
                        Text("SoundView").foregroundColor(.white).foregroundStyle(.primary).font(.largeTitle).padding().frame(alignment: .center)
                            .background(
                                Color.black.gradient, in: Capsule()
                                )
                        Spacer()
                        //Upload song
                        Button {
                            showingFileImporter = true
                        } label: {
                            Image(systemName: "square.and.arrow.up").animation(.easeInOut).font(.title)
                        }.padding().buttonStyle(.borderedProminent).controlSize(.large).fileImporter(isPresented: $showingFileImporter, allowedContentTypes: [.audio], allowsMultipleSelection: false) { result in
                            switch result {
                            case .success(let urls):
                                guard let url = urls.first else {
                                    return
                                }
                                
                                guard url.startAccessingSecurityScopedResource() else {
                                    print("Could not access chosen song due to security restrictions")
                                    return
                                }
                                
                                defer {
                                    url.stopAccessingSecurityScopedResource()
                                }
                                
                                do {
                                    let tempDir = FileManager.default.temporaryDirectory
                                    let dest = tempDir.appendingPathComponent(url.lastPathComponent)
                                    
                                    if FileManager.default.fileExists(atPath: dest.path) {
                                        try FileManager.default.removeItem(at: dest)
                                    }
                                    
                                    try FileManager.default.copyItem(at: url, to: dest)
                                    self.selectedUrl = dest
                                    let asset = AVURLAsset(url: selectedUrl!)
                                    self.songDuration = CMTimeGetSeconds(asset.duration)
                                    self.songNotChosen = false
                                    print("Copied to path: \(dest.path)")
                                } catch {
                                    print("Copy failed: \(error.localizedDescription)")
                                }
                                
                            case .failure(let error):
                                print("Error getting audio file: \(error.localizedDescription)")
                            }
                        }
                        Text("Upload song").foregroundColor(.white)
                        //Song preview (for verifying song with user)
                        if let audioUrl = selectedUrl {
                            Button{
                                do {
                                    if isAudioing {
                                        audioPlayer?.pause()
                                        isAudioing = false
                                    } else {
                                        guard FileManager.default.isReadableFile(atPath: audioUrl.path) else {
                                            print("Audio file not readable")
                                            return
                                        }
                                        
                                        audioPlayer = try AVAudioPlayer(contentsOf: audioUrl)
                                        audioPlayer?.prepareToPlay()
                                        audioPlayer?.play()
                                        isAudioing = true
                                    }
                                } catch {
                                    print("Failed to play song: \(error.localizedDescription)")
                                }
                            } label: {
                                Image(systemName: isAudioing ? "pause.circle" : "play.circle").padding().background(Color.blue).foregroundColor(.white).cornerRadius(10)
                            }
                            Text("Song: \(audioUrl.lastPathComponent)").lineLimit(1).truncationMode(.middle).foregroundColor(.white).frame(alignment: .center)
                        } else {
                            Text("No .m4a song selected").bold().padding().font(.subheadline).foregroundColor(.white).frame(alignment: .center)
                        }
                        
                        Spacer()
                        //Save video, only enabled when video is produced
                        Button {
                            if let finalUrl = videoURL {
                                self.saveVideo(url: finalUrl)
                            }
                        } label: {
                            Image(systemName: "plus.circle").animation(.easeInOut).font(.title)
                        }.padding().buttonStyle(.borderedProminent).controlSize(.large).disabled(videoURL == nil)
                        Text("Save Video").foregroundColor(.white)
                        Spacer()
                        //Delete video and reset app settings
                        Button {
                            showingDeleteConfirm = true
                        } label: {
                            Image(systemName: "trash.circle").animation(.easeInOut).font(.title)
                        }.padding().buttonStyle(.borderedProminent).controlSize(.large)
                        Text("Delete Video").foregroundColor(.white)
                        Spacer()
                        
                        //Info button
                        Button {
                            showingAppInfo = true
                        } label: {
                            Image(systemName: "info.circle").animation(.easeInOut).font(.title)
                        }.padding().buttonStyle(.borderedProminent).controlSize(.large)
                        Text("How to Use").foregroundColor(.white)
                        Spacer()
                        
                    }
                    
                    VStack {
                        HStack {
                            Spacer()
                            
                            //Video generation progress tracker
                            if isGenerating {
                                HStack(spacing: 12) {
                                    ProgressView()
                                    Text(progressMessage).font(.body).foregroundColor(.white).multilineTextAlignment(.center)
                                }.padding().background(Color.black.gradient, in: Rectangle()).animation(.easeInOut, value: isGenerating)
                            }
                            
                            //Video generation prompt
                            TextField(" Enter Prompt for Video Here", text: $promptText).textFieldStyle(RoundedBorderTextFieldStyle()).background(Color.white).font(.title).border(.black).padding()
                            Spacer()
                            
                            //Video options
                            VStack {
                                Button {
                                    showingGenerationOptions = true
                                } label: {
                                    Image(systemName: "ellipsis").animation(.easeInOut).font(.title)
                                }.padding().controlSize(.extraLarge).buttonStyle(.borderedProminent)
                                    .popover(isPresented: $showingGenerationOptions) {
                                        GenerationOptionsView(durationLimit: $durationLimit, songDuration: $songDuration, songStartTime: $songStartTime).frame(width: 300, height: 250)
                                    }
                                Text("Generation Settings").foregroundColor(.white)
                            }
                            //Generate video, pass song, prompt, and video options into generation function
                            Button {
                                if let url = selectedUrl {
                                    generatePrompts()
                                } else {
                                    print("Please select a song")
                                    //give an alert
                                }
                            } label: {
                                Text(isGenerating ? "Generating..." : "Generate Video")//.background(isGenerating ? Color.gray : Color.blue)
                                
                            }.padding().buttonStyle(.borderedProminent).controlSize(.extraLarge).disabled(isGenerating || songNotChosen || promptText == "").foregroundColor(.white)
                            
                            
                        }
                        
                        //Video player displayed once generated
                        if let videoUrl = videoURL{
                            VideoPlayerView(videoURL: videoURL!).padding()
                        }
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity).background {
                    Image("SoundView Background").resizable()
                        .ignoresSafeArea()
                }
            }.navigationViewStyle(StackNavigationViewStyle()).onAppear {
                //Initialize OpenAI API controllers
                imageGenerator.setup()
                promptGenerator.setup()
            }.onDisappear {
                audioPlayer?.stop()
                isAudioing = false
            }.alert("Restart and Delete Video Generation?", isPresented: $showingDeleteConfirm) {
                Button("Reset", role: .destructive) {
                    self.deleteVideo()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will delete your generated video, images, and prompts.")
            }.alert("SoundView Info", isPresented: $showingAppInfo) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Steps to generate video: \n1. Choose a .m4a song you have downloaded to your files. \n2. Enter a prompt into the text field. \n3. Adjust duration in video options dropdown. \n4. Click 'Generate Video' button and wait for prompts and images to be generated. \n5. Once generated, you will have the option to continue with the video generation or to restart.").font(.headline)
            }
        }
    }
    
    // MARK: - Generation Options View
    struct GenerationOptionsView: View {
        @Binding var durationLimit: Double
        @Binding var songDuration: Double
        @Binding var songStartTime: Double
        
        func formatTime(_ seconds: Double) -> String {
            let min = Int(seconds) / 60
            let sec = Int(seconds) % 60
            return String(format: "%d:%02d", min, sec)
        }
        
        var body: some View {
            VStack(alignment: .leading, spacing: 20) {
                    
                Text("")
                durationSlider
                startSlider
                Spacer()
            }
            .padding()
        }
        
        //Choose desired length of video (segments are 10s each)
        var durationSlider: some View {
            VStack {
                Text("Video Duration Limit: \(Int(durationLimit)) seconds").frame(maxWidth: .infinity, alignment: .center)
                Slider(value: $durationLimit, in: 10...songDuration, step: 10).accentColor(Color.blue)
                Text("Amount: $\((durationLimit/10)*0.5+(durationLimit/10)*0.12, specifier: "%.2f")").frame(maxWidth: .infinity, alignment: .center)
            }
        }
        
        //Choose song segment for audio overlay
        var startSlider: some View {
            VStack {
                Text("Start Time: \(formatTime(songStartTime))")
                Text("End Time: \(formatTime(durationLimit + songStartTime))")
                Slider(value: $songStartTime, in: 0...(max(0, songDuration + 1.0 - durationLimit)), step: 1)
            }
        }
    }
    
    // MARK: - Generate Prompts
    func generatePrompts() {
        print("Generating prompts")
        progressMessage = "Generating prompts..."
        isGenerating = true
        let count = Int(durationLimit / 10) //number of prompts to generate based on segments
        let prompt = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        Task {
            let prompts:[String] = await promptGenerator.generatePrompts(prompt: prompt, count: count)!
            guard !prompts.isEmpty else {
                print("No prompts were returned")
                isGenerating = false
                return
            }
            
            self.generatedPrompts = prompts
            
            //Call generateImages once a prompt for each image is created
            generateImages()
        }
    }
    
    // MARK: - Generate Images
    func generateImages() {
        isGenerating = true
        progressMessage = "Generating images..."
        let totalSegments = Int(durationLimit / 10)
        
        if totalSegments != self.generatedPrompts.count {
            print("Wrong number of prompts generated")
            isGenerating = false
            return
        }
        
        Task {
            //prompt OpenAI with previously obtained prompts for each image
            
            let imageUrls:[URL] = await imageGenerator.generateImage(prompts: self.generatedPrompts, count: totalSegments) ?? []
            guard !imageUrls.isEmpty else {
                print("No images were returned")
                progressMessage = "Image generation error, restart and adjust prompt"
                isGenerating = false
                return
            }
            
            self.generatedImages = imageUrls
            self.showingImagePrev = true
        }
            
    }
    
    // MARK: - Generate Video Function
    func generateVideo() {
        
        isGenerating = true
        Task {
            var videos: [URL] = []
            //task Runway API with each individual image and corresponding prompt
            for (index, url) in generatedImages.enumerated() {
                progressMessage = "Generating segment \(index + 1) of \(generatedImages.count)..."
                videoGenerator.setup(url: url, promptText: generatedPrompts[index])
                //group.enter()
                print("Calling Runway API with an image")
                
                
                if let video = await videoGenerator.generateVideo() {
                    print("Segment returned")
                    videos.append(video)
                }
            }
            
            print("All segments generated")
            
            let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("final_video.mp4")
            
            let safeAudio: URL? = {
                guard let url = selectedUrl, FileManager.default.fileExists(atPath: url.path) else {
                    print ("Audio file not found at expected path")
                    return nil
                }
                return url
            }()
            
            guard let finalAudio = safeAudio else {
                print("No valid audio file")
                return
            }
            
            //download each video segment from url array to local directory
            downloadSegments(from: videos) { localVideos in
                
                //Test messaging to console
                print("Video files to combine:")
                for file in localVideos {
                    print(" - \(file.path), exists: \(FileManager.default.fileExists(atPath: file.path))")
                    let asset = AVAsset(url: file)
                    print("Segment duration: \(CMTimeGetSeconds(asset.duration))")
                }
                print("Audio file: \(finalAudio.path), exists: \(FileManager.default.fileExists(atPath: finalAudio.path))")
                
                //combine videos and overlay audio over
                videoCombiner(videoUrls: localVideos, audioUrl: finalAudio, outputUrl: outputUrl) { success in
                    DispatchQueue.main.async {
                        if success {
                            print("Final video produced at: \(outputUrl)")
                            self.videoURL = outputUrl
                            self.progressMessage = ""
                            
                        } else {
                            print("Failed to combine videos")
                            self.videoURL = videos.first
                        }
                    }
                }
            }
        }
    }
        
    // MARK: - Download Video Segments
    func downloadSegments(from urls: [URL], completion: @escaping ([URL]) -> Void) {
        progressMessage = "Downloading segments..."
        var localSegments: [URL?] = Array (repeating: nil, count: urls.count)
        let group = DispatchGroup()
        
        for (index, videoUrl) in urls.enumerated() {
            group.enter()
            
            URLSession.shared.downloadTask(with: videoUrl) { tempUrl, response, error in
                defer {
                    group.leave()
                }
                
                if let error = error {
                    print("Download failed for segment \(index): \(error.localizedDescription)")
                    return
                }
                
                guard let tempUrl = tempUrl else {
                    print("No temp url for segment \(index)")
                    return
                }
                
                let localUrl = FileManager.default.temporaryDirectory.appendingPathComponent("segment_\(index).mp4")
                
                do {
                    if FileManager.default.fileExists(atPath: localUrl.path) {
                        try FileManager.default.removeItem(at: localUrl)
                    }
                    try FileManager.default.moveItem(at: tempUrl, to: localUrl)
                    localSegments[index] = localUrl
                    print("Downloaded segment \(index) to \(localUrl.lastPathComponent)")
                } catch {
                    print("File error for segment \(index): \(error.localizedDescription)")
                }
            }.resume()
        }
        
        group.notify(queue: .main) {
            let valid = localSegments.compactMap { $0 }
            if valid.count == urls.count {
                print("All segments downloaded successfully")
                completion(valid)
            } else {
                print("Only \(valid.count) of \(urls.count) segments downloaded")
                completion([])
            }
            
        }
    }
    
    // MARK: - Combine Segments and Overlay Audio
    func videoCombiner(videoUrls: [URL], audioUrl: URL, outputUrl: URL, completion: @escaping (Bool) -> Void) {
        progressMessage = "Combining segments..."
        
        let mixComposition = AVMutableComposition()
        
        guard let videoTrack = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let audioTrack = mixComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            completion(false)
            return
        }
        
        var insertTime = CMTime.zero
        
        //Combine video segments
        for videoUrl in videoUrls {
            let asset = AVURLAsset(url: videoUrl)
            if let segment = asset.tracks(withMediaType: .video).first {
                do {
                    try videoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: asset.duration), of: segment, at: insertTime)
                    print("Inserted segment with duration: \(CMTimeGetSeconds(asset.duration))")
                } catch {
                    print("Failed to insert video track: \(error)")
                }
                insertTime = CMTimeAdd(insertTime, asset.duration)
            }
        }
        
        //Add audio overlay
        let audioAsset = AVURLAsset(url: audioUrl)
        let duration = insertTime
        if let songTrack = audioAsset.tracks(withMediaType: .audio).first {
            let audioRange = CMTimeRange(start: CMTime(seconds: self.songStartTime, preferredTimescale: 600), duration: duration)
            try? audioTrack.insertTimeRange(audioRange, of: songTrack, at: .zero)
        }
        
        print("Total video duration: \(CMTimeGetSeconds(insertTime)) seconds")
        
        //Export final video
        let exportSession = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality)!
        exportSession.outputURL = outputUrl
        exportSession.outputFileType = .mp4
        exportSession.shouldOptimizeForNetworkUse = true
        
        if FileManager.default.fileExists(atPath: outputUrl.path) {
            try? FileManager.default.removeItem(at: outputUrl)
        }
        
        
        exportSession.exportAsynchronously {
            switch exportSession.status {
            case .completed:
                print("Export completed: \(outputUrl.lastPathComponent)")
                completion(true)
            case .failed:
                print("Export failed: \(exportSession.error?.localizedDescription)")
                completion(false)
            case .cancelled:
                print("Export cancelled")
                completion(false)
            default:
                print("Export ended with status: \(exportSession.status.rawValue)")
                completion(false)
            }
            
        }
        
    }
    
    // MARK: - Save Video
    //stack overflow code
    func saveVideo(url: URL) {
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else {
                print("Not authorized to access photos")
                return
            }
            
            guard FileManager.default.fileExists(atPath: url.path) else {
                print("File doesn't exist at: \(url.path)")
                return
            }
            
            PHPhotoLibrary.shared().performChanges({
                let req = PHAssetCreationRequest.forAsset()
                req.addResource(with: .video, fileURL: url, options: nil)
            }) { success, error in
                DispatchQueue.main.async {
                    if let error = error {
                        print("Could not be saved: \(error.localizedDescription)")
                    } else {
                        print("Saved to photos")
                    }
                }
            }
        }
    }
    
    // MARK: - Delete Video
    func deleteVideo() {
        self.videoURL = nil
        self.generatedImages = []
        self.generatedPrompts = []
        self.showingImagePrev = false
        self.promptText = ""
        self.isGenerating = false
    }
}

#Preview {
    ContentView()
}
 
 
