//
//  SoundviewApp.swift
//  Soundview
//
//  Created by Lincoln Price on 12/21/24.
//

import SwiftUI

@main
struct SoundviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
