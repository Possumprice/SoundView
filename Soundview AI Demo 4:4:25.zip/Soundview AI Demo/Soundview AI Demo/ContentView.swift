//
//  ContentView.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/20/25.
//

import SwiftUI
import AVKit
import Photos

//MARK: App Structure

struct ContentView: View {
    
    @State private var promptText:String = ""
    @State private var isGenerating:Bool = false
    @State private var videoUrl:URL? = nil
    @State private var durationLimit: Double = 15
    
    @StateObject private var musicManager = MusicManager()
    
    @State private var selectedUrl: URL? = nil
    @State private var showingFileImporter = false
    
    var body: some View {
        VStack (spacing: 20) {
            Text("Soundview AI Demo").font(.title).bold().padding()
            
            Button(action: {
                showingFileImporter = true
            }) {
                HStack {
                    Text("Import Song")
                }.padding().background(Color.blue).foregroundColor(Color.white)
            }.fileImporter(isPresented: $showingFileImporter, allowedContentTypes: [.audio], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first {
                        convertToM4A(originalUrl: url) { convertedUrl in
                            DispatchQueue.main.async {
                                if let goodUrl = convertedUrl {
                                    selectedUrl = goodUrl
                                } else {
                                    selectedUrl = url
                                }
                            }
                        }
                    }
                case .failure(let error):
                    print("Error getting audio file: \(error.localizedDescription)")
                }
            }
            
            if let audioUrl = selectedUrl {
                Text("Song: \(audioUrl.lastPathComponent)").lineLimit(1).truncationMode(.middle)
            } else {
                Text("No song selected")
            }
            
            TextField("Enter prompt for video", text: $promptText).textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            VStack {
                Text("Video Duration Limit: \(Int(durationLimit)) seconds, Amount: $\((durationLimit/15)*3.75, specifier: "%.2f")")
                Slider(value: $durationLimit, in: 15...180, step: 15).accentColor(Color.blue)
            }
            
            Button(action: generateVideo) {
                HStack {
                    Text(isGenerating ? "Generating..." : "Generate Video")
                }.padding().frame(maxWidth: .infinity)
            }.disabled(isGenerating).background(isGenerating ? Color.gray : Color.blue).foregroundColor(.white).padding(.horizontal)
            
            if let url = videoUrl {
                VideoPlayer(player: AVPlayer(url: url)).frame(height: 300).padding()
                
                Button(action: {
                    saveVideo(url: videoUrl!)
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.down")
                    }.padding().background(Color.blue).foregroundColor(.white)
                }
                
            } else {
                Rectangle().fill(Color.black).frame(height: 300).padding()
            }
            
            
        }.padding()
    }
    
    //MARK: Generate Video Function
    
    func generateVideo() {
        isGenerating = true
        //guard let song = musicManager.selectedSong else {return}
        
        
        
        //call api here
        //MUSICKIT DOES NOT ALLOW DIRECT FILE-LEVEL AUDIO ACCESS
        //going to instead download preset songs, can get what songs before from interviewees
        //Songs will need to be bundled into the app in .m4a version using FileImporter
        
        guard let fileUrl = selectedUrl else {
            print("Local file not found")
            return
        }
        
        
        let prompt = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        let segmentDuration = CMTime(seconds: 15, preferredTimescale: 600) //depending on payment
        
        VideoSegmenter.splitAudio(assetURL: fileUrl, segmentLength: segmentDuration) { segmentAudioUrls in
            
            let maxSegments = Int(durationLimit / segmentDuration.seconds)
            let limitedSegments = Array(segmentAudioUrls.prefix(maxSegments))
            
            var segmentVideoUrls : [URL] = []
            let group = DispatchGroup()
            
            for (index, _) in segmentAudioUrls.enumerated() {
                group.enter()
                RunwayAPI.generateVideo(for: prompt) { videoUrl in
                    guard let videoUrl = videoUrl else {
                        print("")
                        group.leave()
                        return
                    }
                    let destination = FileManager.default.temporaryDirectory.appendingPathComponent("clip_\(index).mp4") //may change
                    URLSession.shared.downloadTask(with: videoUrl) { tempUrl, response, error in
                        if let tempUrl = tempUrl {
                            try? FileManager.default.moveItem(at: tempUrl, to: destination)
                            segmentVideoUrls.append(destination)
                        } else {
                            print("")
                        }
                        
                        group.leave()
                        
                    }.resume()
                }
            }
            
            group.notify(queue: .main) {
                let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent("final.mp4")
                
                //Combine the clips received
                VideoCombiner.combine(videoSegments: segmentVideoUrls, audioURL: fileUrl, outputURL: outputUrl) { success in
                    DispatchQueue.main.async {
                        if success {
                            self.videoUrl = outputUrl
                        } else {
                            print("Video combination failed")
                        }
                        isGenerating = false
                    }
                } //should sort video urls
            }
        }
    }
    
    func saveVideo(url: URL) {
        PHPhotoLibrary.requestAuthorization { status in
            if status == .authorized {
                PHPhotoLibrary.shared().performChanges( {
                    let request = PHAssetCreationRequest.forAsset()
                    request.addResource(with: .video, fileURL: url, options: nil)
                }) { success, error in DispatchQueue.main.async {
                    if success {
                        print("Video saved")
                    } else {
                        ("Video failed to save: \(error?.localizedDescription ?? "Unknown")")
                    }
                }}
            } else {
                print("access denied")
            }
        }
    }
    
    func convertToM4A(originalUrl: URL, completion: @escaping (URL?) -> Void) {
        let asset = AVAsset(url: originalUrl)
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completion(nil)
            return
        }
        
        let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("m4a")
        exportSession.outputURL = outputUrl
        exportSession.outputFileType = .m4a
        exportSession.timeRange = CMTimeRange(start: .zero, duration: asset.duration)
        
        exportSession.exportAsynchronously {
            if exportSession.status == .completed {
                print("New file: \(outputUrl.lastPathComponent)")
                completion(outputUrl)
            } else {
                print("Failed to convert to .m4a")
                completion(nil)
            }
        }
    }
    
}

#Preview {
    ContentView()
}


