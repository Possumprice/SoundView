//
//  VideoFunctions.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/27/25.
//

import AVFoundation

//MARK: Segment Videos

class VideoSegmenter {
    
    //measure time duration
    static func splitAudio(assetURL: URL, segmentLength: CMTime, completion: @escaping ([URL]) -> Void) {
        
        let asset = AVURLAsset(url: assetURL)
        let duration = asset.duration //maybe limit duration
        var segments: [URL] = []
        
        let outputDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("Segment")
        try? FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
        
        var startTime = CMTime.zero
        var count = 0
        
        //segment here
        while (startTime < duration) {
            let endTime = CMTimeAdd(startTime, segmentLength)
            let timeRange = CMTimeRange(start: startTime, end: segmentLength)
            
            let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A)!
            let outputURL = outputDirectory.appendingPathComponent("segment\(count).m4a")
            exporter.outputURL = outputURL
            exporter.outputFileType = .m4a
            exporter.timeRange = timeRange
            
            let group = DispatchGroup()
            group.enter()
            
            exporter.exportAsynchronously {
                if exporter.status == .completed {
                    segments.append(outputURL)
                } else {
                    //error
                }
                group.leave()
            }
            
            group.wait()
            
            startTime = endTime
            count = count + 1
        }
        
    }
}

//MARK: Combine Videos

class VideoCombiner {
    static func combine(videoSegments: [URL], audioURL: URL, outputURL: URL, completion: @escaping (Bool) -> Void) {
        let mixedVideo = AVMutableComposition()
        let videoTrack = mixedVideo.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)!
        let audioTrack = mixedVideo.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)!
        
        var insertTime = CMTime.zero
        
        for segmentUrl in videoSegments {
            let asset = AVAsset(url: segmentUrl)
            
            if let segment = asset.tracks(withMediaType: .video).first {
                try? videoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: asset.duration), of: segment, at: insertTime)
                insertTime = CMTimeAdd(insertTime, asset.duration)
            }
        }
        
        let audioAsset = AVAsset(url: audioURL)
        if let songTrack = audioAsset.tracks(withMediaType: .audio).first {
            try? audioTrack.insertTimeRange(CMTimeRange(start: .zero, duration: insertTime), of: songTrack, at: .zero)
        }
        
        
        let exporter = AVAssetExportSession(asset: mixedVideo, presetName: AVAssetExportPresetHighestQuality)!
        exporter.outputURL = outputURL
        exporter.outputFileType = .mp4
        exporter.exportAsynchronously {
            completion(exporter.status == .completed)
        }
    }
}
