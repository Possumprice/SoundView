//
//  MusicManager.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/21/25.
//
import Foundation
import MusicKit

class MusicManager : ObservableObject {
    @Published var selectedSong: Song?
    
    func requestMusicAccessAndGetSong() async {
        do {
            let status = await MusicAuthorization.request()
            guard status == .authorized else {
                print("Music access not authorized")
                return
            }
            
            let request = MusicCatalogSearchRequest(term: "Moon Kanye West", types: [Song.self])
            let response = try await request.response()
            if let song = response.songs.first {
                DispatchQueue.main.async {
                    self.selectedSong = song
                    print("Selected: \(song.title) by \(song.artistName)")
                }
            } else {
                print("No song found")
            }
        } catch {
            print("Error fetching song: \(error)")
        }
    }
}
