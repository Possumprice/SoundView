//
//  RunwayAPI.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/26/25.
//

import Foundation

struct RunwayAPI {
    static let key = "key_14bcc27e60308a18c873af367d360ab09fe83077e88060b5d09412bbee0208d6dde394ee64e6da6bd3f75006aa37db4d0507c41cc77b5e14274f2717320cd812"
    static let endpoint = URL(string: "https://api.runwayml.com/v1/generate/video")!
    //static let endpoint = URL(string: "https://api.runwayml.com/v1/models/video-generation/run")!
    
    static func generateVideo(for prompt: String, frames: Int = 375, completion: @escaping (URL?) -> Void) {
        
        //build api request
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //parameters, user will be able to change
        let body : [String : Any] = [
            "prompt" : prompt,
            "num_frames" : frames,
            "fps" : 25, //for now, can up depending on time to generate
            "aspect_ratio": "16:9"
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                completion(nil)
                return
            }
            
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String : Any],
               let urlString = json["video_url"] as? String,
               let url = URL(string: urlString) {
                completion(url)
            } else {
                completion(nil)
            }
        }.resume()
    }
}
