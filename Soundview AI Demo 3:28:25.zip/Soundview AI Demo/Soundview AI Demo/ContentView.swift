//
//  ContentView.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/20/25.
//

import SwiftUI
import AVKit

//MARK: App Structure

struct ContentView: View {
    
    @State private var promptText:String = ""
    @State private var isGenerating:Bool = false
    @State private var videoURL:URL? = nil
    
    @StateObject private var musicManager = MusicManager()
    
    var body: some View {
        VStack (spacing: 20) {
            Text("Soundview AI Demo").font(.title).bold()
            
            
            TextField("Enter prompt for video", text: $promptText).textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: generateVideo) {
                HStack {
                    Text(isGenerating ? "Generating..." : "Generate Video")
                }.padding().frame(maxWidth: .infinity)
            }.disabled(isGenerating).background(isGenerating ? Color.gray : Color.blue).foregroundColor(.white).padding(.horizontal)
            
            if let url = videoURL {
                VideoPlayer(player: AVPlayer(url: url)).frame(height: 300).padding()
            } else {
                Rectangle().fill(Color.black).frame(height: 300).padding()
            }
        }.padding()
    }
    
    //MARK: Generate Video Function
    
    func generateVideo() {
        isGenerating = true
        //guard let song = musicManager.selectedSong else {return}
        
        
        
        //call api here
        //MUSICKIT DOES NOT ALLOW DIRECT FILE-LEVEL AUDIO ACCESS
        //going to instead download preset songs, can get what songs before from interviewees
        //Songs will need to be bundled into the app in .m4a version using FileImporter
        
        guard let fileUrl = Bundle.main.url(forResource: "[SONG FILE NAME HERE]", withExtension: "m4a") else {
            print("Local file not found")
            return
        }
        
        
        let prompt = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        let segmentDuration = CMTime(seconds: 15, preferredTimescale: 600) //depending on payment
        
        VideoSegmenter.splitAudio(assetURL: fileUrl, segmentLength: segmentDuration) { segmentAudioUrls in
            var segmentVideoUrls : [URL] = []
            let group = DispatchGroup()
            
            for (index, _) in segmentAudioUrls.enumerated() {
                group.enter()
                RunwayAPI.generateVideo(for: prompt) { videoUrl in
                    guard let videoUrl = videoUrl else {
                        print("")
                        group.leave()
                        return
                    }
                    let destination = FileManager.default.temporaryDirectory.appendingPathComponent("clip_\(index).mp4") //may change
                    URLSession.shared.downloadTask(with: videoUrl) { tempUrl, response, error in
                        if let tempUrl = tempUrl {
                            try? FileManager.default.moveItem(at: tempUrl, to: destination)
                            segmentVideoUrls.append(destination)
                        } else {
                            print("")
                        }
                        
                        group.leave()
                        
                    }.resume()
                }
            }
            
            group.notify(queue: .main) {
                let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent("final.mp4")
                
                //Combine the clips received
                VideoCombiner.combine(videoSegments: segmentVideoUrls, audioURL: fileUrl, outputURL: outputUrl) { success in
                    DispatchQueue.main.async {
                        if success {
                            self.videoURL = outputUrl
                        } else {
                            print("Video combination failed")
                        }
                        isGenerating = false
                    }
                } //should sort video urls
            }
        }
    }
}

#Preview {
    ContentView()
}


