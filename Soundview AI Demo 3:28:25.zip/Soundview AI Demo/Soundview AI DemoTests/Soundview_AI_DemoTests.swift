//
//  Soundview_AI_DemoTests.swift
//  Soundview AI DemoTests
//
//  Created by Lincoln Price on 3/20/25.
//

import Testing

struct Soundview_AI_DemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
