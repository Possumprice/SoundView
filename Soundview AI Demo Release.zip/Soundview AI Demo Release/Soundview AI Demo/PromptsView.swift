//
//  PromptsView.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 5/28/25.
//

import SwiftUI
import OpenAIKit


struct PromptsView: View {
    @StateObject var chatGenerator: ChatGenerator = .init()
    @State var newPrompt: String = ""
    let strings: [String]
    let onGenerate: () -> Void
    
    let isGenerating = false
    
    var body: some View {
        VStack {
            Text("Generated Prompts").font(.title).bold()
        }
        ScrollView {
            ForEach(strings, id: \.self) { message in
                MessageView(message: message).padding(5)
            }
        }
        Spacer()
        Button(action: onGenerate) {
            Text("Continue with Generation").bold().frame(maxWidth: .infinity).padding().background(Color.blue).foregroundColor(.white).padding(.horizontal)
        }
            
        Divider()
        HStack {
            TextField("Redo Prompt", text: self.$newPrompt, axis: .vertical).padding().cornerRadius(10)
            Button {
                    //Call generation again
            } label: {
                Image(systemName: "paperplane")
            }

        }
        
    }
    
}

struct MessageView: View {
    var message: String
    
    var body: some View {
        Group {
            HStack {
                Text(message).padding().background(Color.blue).clipShape(.capsule).foregroundColor(.white)
                Spacer()
            }
        }
    }
}
