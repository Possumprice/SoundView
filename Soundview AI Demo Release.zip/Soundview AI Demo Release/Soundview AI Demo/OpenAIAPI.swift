//
//  OpenAIAPI.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 4/7/25.
//

import Foundation
import OpenAIKit

//MARK: Image Generator
final class ImageGenerator: ObservableObject {
    private var api: OpenAI?
    
    func setup() {
        api = OpenAI(Configuration(organizationId: "Personal", apiKey: "{YOUR_API_KEY}"))
    }
    
    func generateImage(prompts: [String], count: Int) async -> [URL]? {
        print("Generating images")
        guard let api = api else {
            return nil
        }
        
        var imageUrls: [URL] = []
        
        for prompt in prompts {
            do {
                let params = ImageParameters(prompt: prompt, numberofImages: 1, resolution: .large, responseFormat: .url)
                let result = try await api.createImage(parameters: params)
                let data = result.data
                let imageUrl: URL = URL(string: data[0].image)!
                imageUrls.append(imageUrl)
                //let imageUrls: [URL] = data.compactMap { URL(string: $0.image) }
                //return imageUrls
            } catch {
                print("Failed to produce images: \(error)")
                return nil
            }
        }
        return imageUrls
    }
    
}

//MARK: Prompt Generator
final class ChatGenerator: ObservableObject {
    private var api: OpenAI?
    @Published var messages: [ChatMessage] = []
    
    //not sure if this is needed
    struct Message: Identifiable {
        var id: UUID = .init()
        var content: String
        var isUser: Bool
    }
    
    func setup() {
        api = OpenAI(Configuration(organizationId: "Personal", apiKey: "{YOUR_API_KEY}"))
    }
    
    func generatePrompts(prompt: String, count: Int) async -> [String]? {
        do {
            let chat: [ChatMessage] = [
                ChatMessage(role: .system, content: "You are a vivid, descriptive, illustrative writer, akin to Charles Dickens. Your passion is to create the best prompts for AI music videos possible. You transform given prompts into complete stories with a strict length of \(count) sentences. Each sentence should be descriptive enough to transfer into image format and should tell a complete scene of the story. The stories should have some thematic resonance to them."),
                //ChatMessage(role: .system, content: "You are a vivid, descriptive, illustrative writer, akin to Charles Dickens. Your passion is to create the best prompts for AI music videos possible. You transform given prompts into complete stories with a strict length of \(count) sentences. Each sentence should be descriptive enough to transfer into image format and should tell a complete scene of the story. They should also each indicate the color scheme, style, or specific entities if indicated in the original prompt. Do not use pronouns and instead be as specific as possible when reffering to objects or people, even as the story progresses. The stories should have some thematic resonance to them.")
                ChatMessage(role: .user, content: prompt)
            ]
            
            let chatParams = ChatParameters(model: .gpt4, messages: chat)
            
            let chatCompletion = try await api?.generateChatCompletion(parameters: chatParams)
            
            if let message = chatCompletion?.choices[0].message {
                let content = message.content!
                print(content)
                //Separate prompt by sentences
                let prompts = content.components(separatedBy: ". ").flatMap { $0.components(separatedBy: "! ")}.flatMap { $0.components(separatedBy: "? ")}.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) + "."}
                for (index, prompt) in prompts.enumerated() {
                    print("Prompt \(index): \(prompt)")
                }
                return prompts
            }
            return nil
        } catch {
            print("Failed to produce prompts: \(error.localizedDescription)")
            return nil
        }
    }
}
