//
//  Soundview_AI_DemoApp.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/20/25.
//

import SwiftUI

@main
struct Soundview_AI_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
