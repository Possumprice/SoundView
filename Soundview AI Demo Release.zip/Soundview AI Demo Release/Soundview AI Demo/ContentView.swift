//
//  ContentView.swift
//  Soundview AI Demo
//
//  Created by Lincoln Price on 3/20/25.
//

// DO NEXT:
// DELETE/RESTART BUTTON NEXT TO SAVE
// MULTIPLE PROMPTS? OR PROMPT CHATGPT TO CREATE A SERIES OF PROMPTS FOR A STORY (DELINEATE BY SENTENCE, ONE SENTENCE PER PROMPT) EACH PROMPT IS A DIFFERENT IMAGE AS WELL

import SwiftUI
import AVKit
import Photos
import AVFoundation

//MARK: App Structure

struct ContentView: View {
    @ObservedObject var chatGenerator = ChatGenerator()
    @ObservedObject var imageGenerator = ImageGenerator()
    @ObservedObject var videoGenerator = VideoGenerator()
    
    @State private var generatedPrompts: [String] = []
    @State private var generatedImages: [URL] = []
    
    @State private var showingImagePrev = false
    @State private var showingPromptPrev = false
    @State private var showingDeleteConfirm = false
    @State private var showingGenerationOptions = false
    
    @State private var promptText:String = ""
    @State private var isGenerating:Bool = false
    @State private var videoUrl:URL? = nil
    @State private var durationLimit: Double = 10
    
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isAudioing = false
        
    @State private var selectedUrl: URL? = nil
    @State private var showingFileImporter = false
    
    var body: some View {
        
        if showingImagePrev {
            ImagesView(imageUrls: generatedImages, prompts: generatedPrompts) {
                generateVideo()
                showingImagePrev = false
            }
        } else {
            VStack (spacing: 20) {
                
                songView
                
                generateView
                
                if let finalUrl = videoUrl {
                    VideoPlayer(player: AVPlayer(url: finalUrl)).frame(height: 300).padding()
                    
                    HStack {
                        Button(action: {
                            self.saveVideo(url: finalUrl)
                        }) {
                            Image(systemName: "square.and.arrow.down").padding().background(Color.blue).foregroundColor(.white).cornerRadius(10)
                        }
                        
                        Button(action: {
                            showingDeleteConfirm = true
                        }) {
                            Image(systemName: "trash").background(Color.red).foregroundColor(.white).padding().cornerRadius(10)
                        }
                    }
                    
                    Spacer()
                    
                } else {
                    Rectangle().fill(Color.black).frame(height: 300).padding()
                }
                
            }.onAppear {
                imageGenerator.setup()
                chatGenerator.setup()
            }.onDisappear {
                audioPlayer?.stop()
                isAudioing = false
            }.alert("Restart and Delete Video Generation?", isPresented: $showingDeleteConfirm) {
                Button("Reset", role: .destructive) {
                    deleteVideo()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will delete your generated video, all images, and prompts.")
            }.padding()
        }
    }
    
    //MARK: Song View
    var songView: some View {
        VStack {
            Text("Soundview AI Demo").font(.title).bold().padding()
            
            Button(action: {
                showingFileImporter = true
            }) {
                HStack {
                    Text("Import Song")
                }.padding().background(Color.blue).foregroundColor(Color.white)
            }.fileImporter(isPresented: $showingFileImporter, allowedContentTypes: [.audio], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else {
                        return
                    }
                    
                    guard url.startAccessingSecurityScopedResource() else {
                        print("Could not access security-scoped resource")
                        return
                    }
                    
                    defer {
                        url.stopAccessingSecurityScopedResource()
                    }
                    
                    do {
                        let tempDir = FileManager.default.temporaryDirectory
                        let dest = tempDir.appendingPathComponent(url.lastPathComponent)
                        
                        if FileManager.default.fileExists(atPath: dest.path) {
                            try FileManager.default.removeItem(at: dest)
                        }
                        
                        try FileManager.default.copyItem(at: url, to: dest)
                        selectedUrl = dest
                        print("Copied to path: \(dest.path)")
                    } catch {
                        print("Copy failed: \(error)")
                    }
                    
                case .failure(let error):
                    print("Error getting audio file: \(error.localizedDescription)")
                }
            }
            
            if let audioUrl = selectedUrl {
                Button(action: {
                    do {
                        if isAudioing {
                            audioPlayer?.pause()
                            isAudioing = false
                        } else {
                            guard FileManager.default.isReadableFile(atPath: audioUrl.path) else {
                                print("Audio file not readable")
                                return
                            }
                            audioPlayer = try AVAudioPlayer(contentsOf: audioUrl)
                            audioPlayer?.prepareToPlay()
                            audioPlayer?.play()
                            isAudioing = true
                            
                        }
                    } catch {
                        print("Failed to playback song: \(error.localizedDescription)")
                    }
                    
                }) {
                    Image(systemName: isAudioing ? "pause.circle" : "play.circle").padding().background(Color.blue).foregroundColor(.white).cornerRadius(10)
                }
                Text("Song: \(audioUrl.lastPathComponent)").lineLimit(1).truncationMode(.middle)
            } else {
                Text("No song selected")
            }
        }
    }
    
    //MARK: Generate View
    var generateView: some View {
        VStack {
            TextField("Enter prompt for video", text: $promptText).textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            VStack {
                Text("Video Duration Limit: \(Int(durationLimit)) seconds, Amount: $\((durationLimit/10)*0.5+(durationLimit/10)*0.12, specifier: "%.2f")")
                Slider(value: $durationLimit, in: 10...180, step: 10).accentColor(Color.blue)
            }
            
            Button(action: generatePrompts) {
                HStack {
                    Text(isGenerating ? "Generating..." : "Generate Video")
                }.padding().frame(maxWidth: .infinity)
            }.disabled(isGenerating).background(isGenerating ? Color.gray : Color.blue).foregroundColor(.white).padding(.horizontal)
        }
    }
    
    //MARK: Generate Prompts Function
    func generatePrompts() {
        isGenerating = true
        let count = Int(durationLimit / 10)
        let prompt = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        Task {
            let prompts:[String] = await chatGenerator.generatePrompts(prompt: prompt, count: count)!
            guard !prompts.isEmpty else {
                print("No prompts were returned")
                isGenerating = false
                return
            }
            
            self.generatedPrompts = prompts
            generateImages()
        }
        
    }
    
    //MARK: Generate Images Function
    func generateImages() {
        isGenerating = true
        let totalSegments = Int(durationLimit / 10)
        
        if totalSegments != self.generatedPrompts.count {
            print("Wrong number of prompts generated")
            isGenerating = false
            return
        }
        
        let prompt = promptText.trimmingCharacters(in: .whitespacesAndNewlines)
        if self.generatedPrompts.isEmpty {
            self.generatedPrompts.append(prompt)
        }
        
        Task {
            let imageUrls:[URL] = await imageGenerator.generateImage(prompts: self.generatedPrompts, count: totalSegments)!
            guard !imageUrls.isEmpty else {
                print("No images were returned")
                isGenerating = false
                return
            }
            
            self.generatedImages = imageUrls
            self.showingImagePrev = true
        }
    }
    
    //MARK: Generate Video Function
    
    func generateVideo() {
        isGenerating = true
        let totalSegments = Int(durationLimit / 10)
    
        
        var videos: [URL] = []
        
        Task {
            var videos: [URL] = []
            for (index, url) in generatedImages.enumerated() {
                videoGenerator.setup(url: url, promptText: generatedPrompts[index])
                //group.enter()
                print("Calling Runway API with an image")
                
                
                if let video = await videoGenerator.generateVideo() {
                    print("Segment returned")
                    videos.append(video)
                    
                }
            }
        
            print("All segments generated")
        
            let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("final_video.mp4")
        
            let safeAudio: URL? = {
                guard let url = selectedUrl, FileManager.default.fileExists(atPath: url.path) else {
                    print ("Audio file not found at expected path")
                    return nil
                }
                return url
            }()
            
            guard let finalAudio = safeAudio else {
                print("No valid audio file")
                return
            }
            
            downloadSegments(from: videos) { localVideos in
                print("Video files to combine:")
                for file in localVideos {
                    print(" - \(file.path), exists: \(FileManager.default.fileExists(atPath: file.path))")
                    let asset = AVAsset(url: file)
                    print("Segment duration: \(CMTimeGetSeconds(asset.duration))")
                }
                print("Audio file: \(finalAudio.path), exists: \(FileManager.default.fileExists(atPath: finalAudio.path))")
                videoCombiner(videoUrls: localVideos, audioUrl: finalAudio, outputUrl: outputUrl) { success in
                    DispatchQueue.main.async {
                        if success {
                            print("Final video produced at: \(outputUrl)")
                            self.videoUrl = outputUrl
                        } else {
                            print("Failed to combine video")
                            self.videoUrl = videos.first //this isn't being saved, which is causing the error when trying to save
                        }
                    }
                }
            }
        }
        
            
        
    }
    
    // MARK: Download Video Segments
    func downloadSegments(from urls: [URL], completion: @escaping ([URL]) -> Void) {
        var localSegments: [URL?] = Array (repeating: nil, count: urls.count)
        let group = DispatchGroup()
        
        for (index, videoUrl) in urls.enumerated() {
            group.enter()
            
            URLSession.shared.downloadTask(with: videoUrl) { tempUrl, response, error in
                defer {
                    group.leave()
                }
                
                if let error = error {
                    print("Download failed for segment \(index): \(error.localizedDescription)")
                    return
                }
                
                guard let tempUrl = tempUrl else {
                    print("No temp url for segment \(index)")
                    return
                }
                
                let localUrl = FileManager.default.temporaryDirectory.appendingPathComponent("segment_\(index).mp4")
                
                do {
                    if FileManager.default.fileExists(atPath: localUrl.path) {
                        try FileManager.default.removeItem(at: localUrl)
                    }
                    try FileManager.default.moveItem(at: tempUrl, to: localUrl)
                    localSegments[index] = localUrl
                    print("Downloaded segment \(index) to \(localUrl.lastPathComponent)")
                } catch {
                    print("File error for segment \(index): \(error.localizedDescription)")
                }
            }.resume()
        }
        
        group.notify(queue: .main) {
            let valid = localSegments.compactMap { $0 }
            if valid.count == urls.count {
                print("All segments downloaded successfully")
                completion(valid)
            } else {
                print("Only \(valid.count) of \(urls.count) segments downloaded")
                completion([])
            }
            
        }
    }
    
    // MARK: Combine Segments and Overlay Audio
    func videoCombiner(videoUrls: [URL], audioUrl: URL, outputUrl: URL, completion: @escaping (Bool) -> Void) {
        let mixComposition = AVMutableComposition()
        
        guard let videoTrack = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let audioTrack = mixComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            completion(false)
            return
        }
        
        var insertTime = CMTime.zero
        
        //Combine video segments
        for videoUrl in videoUrls {
            let asset = AVURLAsset(url: videoUrl)
            if let segment = asset.tracks(withMediaType: .video).first {
                do {
                    try videoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: asset.duration), of: segment, at: insertTime)
                    print("Inserted segment with duration: \(CMTimeGetSeconds(asset.duration))")
                } catch {
                    print("Failed to insert video track: \(error)")
                }
                insertTime = CMTimeAdd(insertTime, asset.duration)
            }
        }
        
        //Add audio overlay
        let audioAsset = AVURLAsset(url: audioUrl)
        let duration = insertTime
        if let songTrack = audioAsset.tracks(withMediaType: .audio).first {
            let audioRange = CMTimeRange(start: .zero, duration: duration)
            try? audioTrack.insertTimeRange(audioRange, of: songTrack, at: .zero)
        }
        
        print("Total video duration: \(CMTimeGetSeconds(insertTime)) seconds")
        
        //Export final video
        let exportSession = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality)!
        exportSession.outputURL = outputUrl
        exportSession.outputFileType = .mp4
        exportSession.shouldOptimizeForNetworkUse = true
        
        if FileManager.default.fileExists(atPath: outputUrl.path) {
            try? FileManager.default.removeItem(at: outputUrl)
        }
        
        exportSession.exportAsynchronously {
            switch exportSession.status {
            case .completed:
                print("Export completed: \(outputUrl.lastPathComponent)")
                completion(true)
            case .failed:
                print("Export failed: \(exportSession.error?.localizedDescription)")
                completion(false)
            case .cancelled:
                print("Export cancelled")
                completion(false)
            default:
                print("Export ended with status: \(exportSession.status.rawValue)")
                completion(false)
            }
            
        }
        
    }
    
    // MARK: Save Video
    
    
    func saveVideo(url: URL) {
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else {
                print("Not authorized to access photos")
                return
            }
            
            guard FileManager.default.fileExists(atPath: url.path) else {
                print("File doesn't exist at: \(url.path)")
                return
            }
            
            PHPhotoLibrary.shared().performChanges({
                let req = PHAssetCreationRequest.forAsset()
                req.addResource(with: .video, fileURL: url, options: nil)
            }) { success, error in
                DispatchQueue.main.async {
                    if let error = error {
                        print("Could not be saved: \(error.localizedDescription)")
                    } else {
                        print("Saved to photos")
                    }
                }
            }
        }
    }
    
    
    // MARK: Convert Song to M4A
    func convertToM4A(originalUrl: URL, completion: @escaping (URL?) -> Void) {
        let asset = AVAsset(url: originalUrl)
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completion(nil)
            return
        }
        
        let outputUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("m4a")
        exportSession.outputURL = outputUrl
        exportSession.outputFileType = .m4a
        exportSession.timeRange = CMTimeRange(start: .zero, duration: asset.duration)
        
        exportSession.exportAsynchronously {
            if exportSession.status == .completed {
                print("New file: \(outputUrl.lastPathComponent)")
                completion(outputUrl)
            } else {
                print("Failed to convert to .m4a")
                completion(nil)
            }
        }
    }
    
    //MARK: Delete Video
    func deleteVideo() {
        self.videoUrl = nil
        self.generatedImages = []
        self.generatedPrompts = []
        self.showingImagePrev = false
        self.promptText = ""
        self.isGenerating = false
    }
}


#Preview {
    ContentView()
}


